<?php if (isset($component)) { $__componentOriginalf2b16bc3883246ba4659aff94e382522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2b16bc3883246ba4659aff94e382522 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: "<?php echo e(session('success')); ?>",
                    showConfirmButton: false,
                    timer: 5000,
                    position: 'mid'
                });
            });
        </script>
    <?php endif; ?>

    <div class="max-w-screen-xl mx-auto px-4 lg:px-8 py-8">
        
        <div x-data="{ currentSlide: 0, interval: null }" x-init="interval = setInterval(() => { currentSlide = (currentSlide + 1) % <?php echo e(max(count($banners), 1)); ?> }, 5000);" class="relative overflow-hidden rounded-xl shadow-md mb-12">

            <div class="flex transition-transform duration-700 ease-out"
                :style="'transform: translateX(-' + (currentSlide * 100) + '%)'">
                <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="w-full flex-shrink-0">
                        <div class="aspect-[2/1]">
                            <?php if($banner->image): ?>
                                <img src="<?php echo e(asset('storage/' . $banner->image)); ?>" class="w-full h-full object-cover"
                                    alt="Banner">
                            <?php else: ?>
                                <div class="w-full h-full flex items-center justify-center bg-gray-200 text-gray-500">
                                    No image available
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="w-full aspect-[2/1] flex items-center justify-center bg-gray-100 text-gray-500">
                        No image available
                    </div>
                <?php endif; ?>
            </div>

            
            <button @click="currentSlide = (currentSlide - 1 + <?php echo e(count($banners)); ?>) % <?php echo e(count($banners)); ?>"
                class="absolute top-1/2 left-3 -translate-y-1/2 bg-white/70 hover:bg-white text-gray-800 p-2 rounded-full shadow">
                &#10094;
            </button>
            <button @click="currentSlide = (currentSlide + 1) % <?php echo e(count($banners)); ?>"
                class="absolute top-1/2 right-3 -translate-y-1/2 bg-white/70 hover:bg-white text-gray-800 p-2 rounded-full shadow">
                &#10095;
            </button>

            
            <div class="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button @click="currentSlide = <?php echo e($index); ?>"
                        :class="currentSlide === <?php echo e($index); ?> ? 'bg-blue-600' : 'bg-gray-400'"
                        class="h-2.5 w-2.5 rounded-full transition duration-300"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 text-center mb-16">
            <?php
                $features = [
                    ['img' => 'fashion.png', 'label' => 'Modest & Elegant'],
                    ['img' => 'fabric.png', 'label' => 'Premium Fabric'],
                    ['img' => 'tunic.png', 'label' => 'Sharia Compliant'],
                    ['img' => 'alterations.png', 'label' => 'Perfect Tailored Fit'],
                ];
            ?>

            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex flex-col items-center">
                    <img src="<?php echo e(asset('storage/banks/' . $feature['img'])); ?>" class="w-12 h-12 mb-2"
                        alt="<?php echo e($feature['label']); ?>">
                    <p class="text-sm font-medium text-gray-700"><?php echo e($feature['label']); ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        
        <div class="text-center max-w-3xl mx-auto mb-16 px-4">
            <h2 class="text-2xl font-bold text-gray-800 mb-4">About Toko Al Hakim</h2>
            <p class="text-gray-600 leading-relaxed">
                Toko Al Hakim is a clothing store that offers a variety of Muslim fashion choices that are not only
                comfortable to wear but also meaningful. By prioritizing quality materials, elegant designs, and a touch
                of
                modernity, we present products suitable for daily wear and special occasions.
            </p>
            <p class="text-gray-600 mt-4 leading-relaxed">
                The name "Al Hakim" means "The Most Wise", and that is the value we carry in every product — a wise
                choice, full of consideration, emphasizing simplicity and meaningful beauty.
                Toko Al Hakim is where style meets values.
            </p>
        </div>

        
        <div class="mb-12">
            <h2 class="text-2xl font-bold text-center text-gray-800 mb-8">Trending Products</h2>
            <div class="grid gap-8 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
                <?php $__currentLoopData = $trendingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $variants = $product->variants;
                        $minPrice = $variants->min('price');
                        $maxPrice = $variants->max('price');
                        $soldCount = $product->sold ?? 0;
                    ?>

                    <div
                        class="bg-white border border-gray-200 rounded-lg overflow-hidden shadow hover:shadow-lg transition duration-300 flex flex-col">
                        <a href="<?php echo e(route('user.products.detail', $product->slug)); ?>">
                            <div class="aspect-[4/3] bg-gray-100">
                                <?php if($product->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $product->image)); ?>"
                                        class="w-full h-full object-cover" alt="<?php echo e($product->name); ?>">
                                <?php else: ?>
                                    <div class="h-full w-full flex items-center justify-center text-gray-400">No image
                                    </div>
                                <?php endif; ?>
                            </div>
                        </a>
                        <div class="p-4 flex flex-col flex-grow">
                            <a href="<?php echo e(route('user.products.detail', $product->slug)); ?>"
                                class="text-base font-semibold text-gray-800 hover:text-blue-600 truncate"
                                title="<?php echo e($product->name); ?>">
                                <?php echo e(Str::limit($product->name, 40)); ?>

                            </a>

                            <div class="mt-1 flex justify-between items-center text-sm text-gray-500">
                                <div class="flex items-center space-x-1">
                                    <span>⭐</span>
                                    <span><?php echo e(number_format($product->average_rating, 1)); ?></span>
                                </div>
                                <div><?php echo e($soldCount > 0 ? "Terjual $soldCount" : ''); ?></div>
                            </div>

                            <div class="mt-3">
                                <?php if($minPrice === $maxPrice): ?>
                                    <p class="text-lg font-bold text-gray-900">
                                        Rp<?php echo e(number_format($minPrice, 0, ',', '.')); ?>

                                    </p>
                                <?php else: ?>
                                    <p class="text-sm font-medium text-gray-800">
                                        Rp<?php echo e(number_format($minPrice, 0, ',', '.')); ?> -
                                        Rp<?php echo e(number_format($maxPrice, 0, ',', '.')); ?>

                                    </p>
                                <?php endif; ?>
                            </div>

                            <div class="mt-auto pt-4">
                                <a href="<?php echo e(route('user.products.detail', $product->slug)); ?>"
                                    class="block text-center bg-blue-600 text-white font-semibold py-2 rounded-md hover:bg-blue-700 transition">
                                    View Product
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $attributes = $__attributesOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__attributesOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $component = $__componentOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__componentOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/user/index.blade.php ENDPATH**/ ?>