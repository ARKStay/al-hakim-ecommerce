<?php if (isset($component)) { $__componentOriginalb998c89882eab8e1df2af93927d4d429 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb998c89882eab8e1df2af93927d4d429 = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

    <section class="pt-2 pb-6 bg-white md:pt-4 md:pb-12 dark:bg-gray-900">
        <div class="max-w-screen-xl px-4 mx-auto">
            
            <nav class="text-base text-gray-500 mb-2 md:mt-4" aria-label="Breadcrumb">
                <ol class="list-reset flex">
                    <li>
                        <a href="/dashboard/products" class="text-blue-500 hover:underline">Products</a>
                        <span class="mx-2">/</span>
                    </li>
                    <li class="text-gray-700 dark:text-gray-300 truncate max-w-[400px]"><?php echo e($product->name); ?></li>
                </ol>
            </nav>

            
            <div class="grid md:grid-cols-2 gap-10">
                
                <div>
                    <div class="w-full aspect-[3/2] bg-gray-100 flex items-center justify-center border rounded">
                        <img id="mainImage" class="object-contain h-full"
                            src="<?php echo e(asset('storage/' . ($product->image ?? 'placeholder.jpg'))); ?>"
                            alt="<?php echo e($product->name); ?>">
                    </div>
                    <div class="flex mt-4 gap-2 flex-wrap">
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" onclick="resetMainImage()"
                                class="w-16 h-16 object-cover border cursor-pointer rounded thumbnail" alt="Main Image">
                        <?php endif; ?>
                        <?php $__currentLoopData = $product->variants->unique('color'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($variant->variant_image): ?>
                                <img src="<?php echo e(asset('storage/' . $variant->variant_image)); ?>"
                                    data-color="<?php echo e($variant->color); ?>" onclick="selectColor('<?php echo e($variant->color); ?>')"
                                    class="w-16 h-16 object-cover border cursor-pointer rounded thumbnail variant-thumbnail"
                                    alt="<?php echo e($variant->color); ?>">
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>

                
                <div>
                    <h1 class="text-2xl font-bold text-gray-900 dark:text-white truncate max-w-[90%]">
                        <?php echo e($product->name); ?></h1>
                    <div class="mt-2 text-green-600 text-3xl font-semibold" id="price">
                        Rp<?php echo e(number_format($product->variants->first()->price, 0, ',', '.')); ?>

                    </div>

                    
                    <div class="mt-6">
                        <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">Available Colors:</h3>
                        <div class="flex flex-wrap gap-2 mt-2">
                            <?php $__currentLoopData = $product->variants->unique('color'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-3 py-1 rounded border text-sm font-medium bg-white text-gray-800">
                                    <?php echo e(ucfirst($variant->color)); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div class="mt-4">
                        <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300">Available Sizes:</h3>
                        <div class="flex flex-wrap gap-2 mt-2 min-h-[40px]" id="sizeOptions">
                            <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="px-3 py-1 text-sm rounded border bg-white text-gray-800">
                                    <?php echo e(ucfirst($variant->color)); ?> - <?php echo e($variant->size); ?> |
                                    Rp<?php echo e(number_format($variant->price, 0, ',', '.')); ?> | Stock: <?php echo e($variant->stock); ?>

                                </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>

                    
                    <div class="mt-6 p-4 border rounded bg-gray-50 dark:bg-gray-800 dark:border-gray-700 max-w-md">
                        <h3 class="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3">Product Stats:</h3>
                        <div class="text-sm text-gray-600 dark:text-gray-300">
                            <p>Average Rating: <strong><?php echo e(number_format($average_rating, 1) ?? '-'); ?></strong></p>
                            <p>Total Ratings: <strong><?php echo e($total_ratings ?? 0); ?></strong></p>
                            <p>Sold: <strong><?php echo e($product->sold ?? 0); ?></strong></p>
                        </div>
                    </div>
                </div>
            </div>

            <hr class="my-10 border-gray-300" />

            
            <div class="grid md:grid-cols-3 gap-10">
                <div class="md:col-span-2">
                    <div class="p-6 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800">
                        <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Product Description</h2>
                        <div class="mt-4 text-gray-600 dark:text-gray-300 prose dark:prose-invert">
                            <?php echo $product->description ?? '<p>No description available.</p>'; ?>

                        </div>
                    </div>
                </div>
                <div>
                    <div class="p-6 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-gray-800">
                        <h2 class="text-lg font-semibold text-gray-900 dark:text-white">Customer Reviews</h2>
                        <div class="mt-4 space-y-4 max-h-96 overflow-y-auto">
                            <?php $__empty_1 = true; $__currentLoopData = $product->ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="border-t pt-4">
                                    <div class="flex justify-between text-sm text-gray-700 dark:text-gray-400">
                                        <span><strong><?php echo e($rating->user->username); ?></strong></span>
                                        <span><?php echo e($rating->created_at->format('d M Y')); ?></span>
                                    </div>
                                    <div class="mt-1 text-yellow-500">
                                        <?php for($i = 0; $i < 5; $i++): ?>
                                            <i
                                                class="fas fa-star <?php echo e($i < $rating->rating ? 'text-yellow-500' : 'text-gray-300'); ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <p class="text-gray-600 dark:text-gray-400 mt-1"><?php echo e($rating->comment ?? '-'); ?></p>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p class="text-gray-500">No reviews yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <script>
        const variants = <?php echo json_encode($product->variants, 15, 512) ?>;

        function selectColor(color) {
            const selectedVariant = variants.find(v => v.color === color);
            if (selectedVariant && selectedVariant.variant_image) {
                document.getElementById('mainImage').src = '/storage/' + selectedVariant.variant_image;
            }
        }

        function resetMainImage() {
            document.getElementById('mainImage').src = '/storage/<?php echo e($product->image); ?>';
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb998c89882eab8e1df2af93927d4d429)): ?>
<?php $attributes = $__attributesOriginalb998c89882eab8e1df2af93927d4d429; ?>
<?php unset($__attributesOriginalb998c89882eab8e1df2af93927d4d429); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb998c89882eab8e1df2af93927d4d429)): ?>
<?php $component = $__componentOriginalb998c89882eab8e1df2af93927d4d429; ?>
<?php unset($__componentOriginalb998c89882eab8e1df2af93927d4d429); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/dashboard/Products/show.blade.php ENDPATH**/ ?>