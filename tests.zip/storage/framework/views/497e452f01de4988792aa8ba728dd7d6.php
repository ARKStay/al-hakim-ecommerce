<?php if (isset($component)) { $__componentOriginalf2b16bc3883246ba4659aff94e382522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2b16bc3883246ba4659aff94e382522 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

    <div class="container mx-auto mt-8">
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border border-gray-300 rounded-lg shadow-sm p-6 mb-6 bg-white">
                <!-- Header Order -->
                <div class="flex justify-between items-center border-b pb-3 mb-3">
                    <div>
                        <p class="text-sm text-gray-500">Order ID: <span
                                class="font-medium text-gray-800">#<?php echo e($order->id); ?></span></p>
                        <p class="text-sm text-gray-500">Order Date:
                            <span class="font-medium"><?php echo e($order->created_at->format('d M Y, H:i')); ?></span>
                        </p>
                    </div>
                    <span
                        class="px-3 py-1 rounded-full text-sm font-medium 
                        <?php echo e($order->order_status === 'completed' ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-500'); ?>">
                        <?php echo e(ucfirst($order->order_status)); ?>

                    </span>
                </div>

                <!-- Item Produk -->
                <div>
                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex items-start gap-4 border-b last:border-0 border-gray-200 py-4">
                            <!-- Gambar produk -->
                            <img src="<?php echo e(asset('storage/' . ($item->variant->variant_image ?? $item->product->image))); ?>"
                                alt="<?php echo e($item->product->name); ?>" class="w-20 h-20 object-cover rounded-md">

                            <!-- Detail produk -->
                            <div class="flex-1">
                                <h3 class="text-sm font-semibold text-gray-800"><?php echo e($item->product->name); ?></h3>
                                <?php if($item->variant): ?>
                                    <p class="text-xs text-gray-500">
                                        Variant:
                                        <span class="font-medium"><?php echo e($item->variant->color ?? '-'); ?></span>,
                                        <span class="font-medium"><?php echo e($item->variant->size ?? '-'); ?></span>
                                    </p>
                                <?php endif; ?>
                                <p class="text-xs text-gray-500">Quantity: <?php echo e($item->quantity); ?></p>
                                <p class="text-xs text-gray-500">Weight: <?php echo e($item->variant->weight ?? '-'); ?> gr</p>
                            </div>

                            <!-- Harga -->
                            <div class="text-right">
                                <p class="text-sm font-medium text-gray-800">
                                    Rp <?php echo e(number_format($item->variant->price ?? $item->product->price, 0, ',', '.')); ?>

                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Footer Order -->
                <div class="mt-4 text-sm text-gray-700 space-y-1">
                    <div class="flex justify-between">
                        <span>Shipping Cost</span>
                        <span>Rp <?php echo e(number_format($order->shipping_cost, 0, ',', '.')); ?></span>
                    </div>
                    <div class="flex justify-between font-semibold text-gray-900">
                        <span>Total Price</span>
                        <span class="text-red-500 text-lg">Rp
                            <?php echo e(number_format($order->total_price, 0, ',', '.')); ?></span>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="my-32 text-center text-gray-500">No purchase history found.</p>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $attributes = $__attributesOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__attributesOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $component = $__componentOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__componentOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/user/history.blade.php ENDPATH**/ ?>