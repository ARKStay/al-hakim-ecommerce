<?php if (isset($component)) { $__componentOriginalf2b16bc3883246ba4659aff94e382522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2b16bc3883246ba4659aff94e382522 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Edit Profile <?php $__env->endSlot(); ?>

    <div class="max-w-screen-md w-full px-4 mx-auto 2xl:px-0 bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">

        
        <nav class="text-base text-gray-500 mb-6 mt-2" aria-label="Breadcrumb">
            <ol class="list-reset flex flex-wrap">
                <li><a href="/user" class="text-blue-500 hover:underline">Home</a><span class="mx-2">/</span></li>
                <li><a href="/user/profile" class="text-blue-500 hover:underline">Profile</a><span class="mx-2">/</span>
                </li>
                <li class="text-gray-700 dark:text-gray-300">Edit Profile</li>
            </ol>
        </nav>

        <h2 class="text-2xl font-semibold mb-8 text-center text-gray-800 dark:text-gray-100">Edit Profile</h2>

        <form id="editForm" action="<?php echo e(route('profile.update', ['user' => auth()->user()->id])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <div>
                    <label for="name" class="block text-gray-700 font-medium">Full Name</label>
                    <input type="text" name="name" id="name" required
                        value="<?php echo e(old('name', auth()->user()->name)); ?>"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                
                <div>
                    <label for="username" class="block text-gray-700 font-medium">Username</label>
                    <input type="text" name="username" id="username" required
                        value="<?php echo e(old('username', auth()->user()->username)); ?>"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                
                <div>
                    <label for="email" class="block text-gray-700 font-medium">Email</label>
                    <input type="email" name="email" id="email" required
                        value="<?php echo e(old('email', auth()->user()->email)); ?>"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                
                <div>
                    <label for="phone" class="block text-gray-700 font-medium">Phone Number</label>
                    <input type="text" name="phone" id="phone"
                        value="<?php echo e(old('phone', auth()->user()->phone)); ?>"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                
                <div class="md:col-span-2">
                    <label for="password" class="block text-gray-700 font-medium">Password</label>
                    <input type="password" name="password" id="password"
                        placeholder="Leave blank to keep current password"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                
                <div class="md:col-span-2">
                    <label for="password_confirmation" class="block text-gray-700 font-medium">Confirm New
                        Password</label>
                    <input type="password" name="password_confirmation" id="password_confirmation"
                        placeholder="Confirm new password"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg">
                </div>

                <?php if($errors->any()): ?>
                    <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded">
                        <ul class="list-disc pl-5 text-sm">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                
                <div class="md:col-span-2">
                    <label for="address" class="block text-gray-700 font-medium">Detailed Address</label>
                    <textarea name="address" id="address" rows="3"
                        class="w-full px-4 py-2 mt-1 bg-gray-100 border border-gray-300 rounded-lg"><?php echo e(old('address', auth()->user()->address)); ?></textarea>
                </div>

                <div class="md:col-span-2 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 p-4 rounded-md">
                    <p class="text-sm">
                        ⚠️ Please note: You need to reselect your <strong>Province</strong>, <strong>City</strong>, and
                        <strong>District</strong> every time you edit your profile.
                    </p>
                </div>

                
                <div>
                    <label for="province" class="block text-gray-700 font-medium">Destination Province</label>
                    <select id="province" name="province_id"
                        class="w-full mt-1 px-4 py-2 bg-gray-200 border border-gray-300 rounded-md shadow-sm">
                        <option value="">-- Select Province --</option>
                        <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($province['id']); ?>"><?php echo e($province['name']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                
                <div>
                    <label for="city" class="block text-gray-700 font-medium">Destination City / Regency</label>
                    <select id="city" name="city_id"
                        class="w-full mt-1 px-4 py-2 bg-gray-200 border border-gray-300 rounded-md shadow-sm disabled:bg-gray-50 disabled:cursor-not-allowed">
                        <option value="">-- Select City --</option>
                    </select>
                </div>

                
                <div>
                    <label for="district" class="block text-gray-700 font-medium">Destination District</label>
                    <select id="district" name="district_id"
                        class="w-full mt-1 px-4 py-2 bg-gray-200 border border-gray-300 rounded-md shadow-sm disabled:bg-gray-50 disabled:cursor-not-allowed">
                        <option value="">-- Select District --</option>
                    </select>
                </div>

                
                <input type="hidden" name="destination_id" id="destination_id"
                    value="<?php echo e(old('destination_id', auth()->user()->destination_id)); ?>">
            </div>

            
            <input type="hidden" name="province_name" id="province_name" value="<?php echo e(old('province_name')); ?>">
            <input type="hidden" name="city_name" id="city_name" value="<?php echo e(old('city_name')); ?>">
            <input type="hidden" name="district_name" id="district_name" value="<?php echo e(old('district_name')); ?>">

            <div class="mt-8 text-center">
                <button type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white text-sm px-6 py-2 rounded-lg shadow-md transition">
                    Save Changes
                </button>
            </div>
        </form>
    </div>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        $(document).ready(function() {
            $('select[name="province_id"]').on('change', function() {
                let provinceId = $(this).val();
                let provinceName = $(this).find('option:selected').text();
                $('#province_name').val(provinceName);

                if (provinceId) {
                    $.ajax({
                        url: `/cities/${provinceId}`,
                        type: "GET",
                        dataType: "json",
                        success: function(response) {
                            $('select[name="city_id"]').empty().append(
                                `<option value="">-- Select City --</option>`);
                            $.each(response, function(index, value) {
                                $('select[name="city_id"]').append(
                                    `<option value="${value.id}">${value.name}</option>`
                                );
                            });

                            // Clear city_name & district_name
                            $('#city_name').val('');
                            $('#district_name').val('');
                        }
                    });
                } else {
                    $('select[name="city_id"]').empty().append(
                        `<option value="">-- Select City --</option>`);
                    $('#province_name').val('');
                }
            });

            $('select[name="city_id"]').on('change', function() {
                let cityId = $(this).val();
                let cityName = $(this).find('option:selected').text();
                $('#city_name').val(cityName);

                if (cityId) {
                    $.ajax({
                        url: `/districts/${cityId}`,
                        type: "GET",
                        dataType: "json",
                        success: function(response) {
                            $('select[name="district_id"]').empty().append(
                                `<option value="">-- Select District --</option>`);
                            $.each(response, function(index, value) {
                                $('select[name="district_id"]').append(
                                    `<option value="${value.id}">${value.name}</option>`
                                );
                            });

                            // Clear district_name
                            $('#district_name').val('');
                        }
                    });
                } else {
                    $('select[name="district_id"]').empty().append(
                        `<option value="">-- Select District --</option>`);
                    $('#city_name').val('');
                }
            });

            $('select[name="district_id"]').on('change', function() {
                let districtName = $(this).find('option:selected').text();
                $('#district_name').val(districtName);
            });

            $('#editForm').on('submit', function(e) {
                let province = $('#province').val();
                let city = $('#city').val();
                let district = $('#district').val();

                if (!province || !city || !district) {
                    e.preventDefault(); // Batalin submit
                    alert(
                        'Please complete your location: Province, City, and District must be selected.');
                }
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $attributes = $__attributesOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__attributesOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $component = $__componentOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__componentOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/user/edit.blade.php ENDPATH**/ ?>