<?php if (isset($component)) { $__componentOriginalf2b16bc3883246ba4659aff94e382522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2b16bc3883246ba4659aff94e382522 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> <?php echo e($title); ?> <?php $__env->endSlot(); ?>

    
    <?php if(session('success') || session('info')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: "<?php echo e(session('success') ? 'success' : 'info'); ?>",
                    title: "<?php echo e(session('success') ? 'Success!' : 'Heads up!'); ?>",
                    text: "<?php echo e(session('success') ?? session('info')); ?>",
                    showConfirmButton: <?php echo e(session('success') ? 'false' : 'true'); ?>,
                    timer: <?php echo e(session('success') ? '3000' : 'null'); ?>,
                    toast: <?php echo e(session('success') ? 'true' : 'false'); ?>,
                    position: <?php echo e(session('success') ? "'bottom-end'" : "'center'"); ?>,
                });
            });
        </script>
    <?php endif; ?>

    <div class="max-w-screen-md w-full px-4 mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">

        
        <nav class="text-sm text-gray-500 mb-6 md:mt-2" aria-label="Breadcrumb">
            <ol class="list-reset flex">
                <li>
                    <a href="/user" class="text-blue-500 hover:underline">Home</a>
                    <span class="mx-2">/</span>
                </li>
                <li class="text-gray-700 dark:text-gray-300">Profile</li>
            </ol>
        </nav>

        
        <div class="flex flex-col md:flex-row justify-between items-center mb-8">
            <h2 class="text-2xl font-semibold text-center md:text-left mb-4 md:mb-0">My Profile</h2>
            <div class="flex gap-4">
                <a href="<?php echo e(route('profile.edit', ['user' => auth()->user()->id])); ?>"
                    class="bg-blue-500 text-white text-sm px-4 py-2 rounded hover:bg-blue-600 transition">
                    Edit Profile
                </a>

                <form action="<?php echo e(route('profile.destroy', ['user' => auth()->user()->id])); ?>" method="POST"
                    id="deleteForm-<?php echo e(auth()->user()->id); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="button" onclick="confirmDelete('<?php echo e(auth()->user()->id); ?>')"
                        class="bg-red-500 text-white text-sm px-4 py-2 rounded hover:bg-red-600 transition">
                        Delete Account
                    </button>
                </form>
            </div>
        </div>

        
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Name</p>
                <p class="text-base font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->name); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Username</p>
                <p class="text-base font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->username); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Email</p>
                <p class="text-base font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->email); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Password</p>
                <p class="text-base font-medium text-gray-900 dark:text-white">
                    <?php echo e(str_repeat('*', min(strlen(auth()->user()->password), 15))); ?>

                </p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Phone Number</p>
                <p class="text-base font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->phone ?? '-'); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow">
                <p class="text-sm text-gray-500">Address</p>
                <p class="text-base font-medium text-gray-900 dark:text-white"><?php echo e(auth()->user()->address ?? '-'); ?></p>
            </div>

            <div class="bg-gray-50 dark:bg-gray-700 p-4 rounded shadow sm:col-span-2">
                <p class="text-sm text-gray-500">Destination</p>
                <p class="text-base font-medium text-gray-900 dark:text-white">
                    <?php echo e(auth()->user()->district_name ?? '-'); ?>,
                    <?php echo e(auth()->user()->city_name ?? '-'); ?>,
                    <?php echo e(auth()->user()->province_name ?? '-'); ?>

                </p>
            </div>
        </div>
    </div>

    
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Are you sure?',
                text: "This action cannot be undone!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    document.getElementById('deleteForm-' + id).submit();
                }
            });
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $attributes = $__attributesOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__attributesOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $component = $__componentOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__componentOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/user/profile.blade.php ENDPATH**/ ?>