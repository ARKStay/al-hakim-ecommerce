<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <script src="https://cdn.jsdelivr.net/npm/flowbite@1.6.5/dist/flowbite.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Trix Editor -->
    <link rel="stylesheet" type="text/css" href="https://unpkg.com/trix@2.0.8/dist/trix.css">
    <link rel="icon" href="<?php echo e(asset('storage/banks/favicon123.ico')); ?>" type="image/x-icon">
    <script type="text/javascript" src="https://unpkg.com/trix@2.0.8/dist/trix.umd.min.js"></script>
    <style>
        trix-toolbar [data-trix-button-group="file-tools"] {
            display: none;
        }
    </style>
    <title>Al Hakim Store</title>
</head>

<body>
    <div class="antialiased bg-gray-50">
        <?php if (isset($component)) { $__componentOriginal24e2055bf31b6a23284333e60f2068dc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal24e2055bf31b6a23284333e60f2068dc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal24e2055bf31b6a23284333e60f2068dc)): ?>
<?php $attributes = $__attributesOriginal24e2055bf31b6a23284333e60f2068dc; ?>
<?php unset($__attributesOriginal24e2055bf31b6a23284333e60f2068dc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal24e2055bf31b6a23284333e60f2068dc)): ?>
<?php $component = $__componentOriginal24e2055bf31b6a23284333e60f2068dc; ?>
<?php unset($__componentOriginal24e2055bf31b6a23284333e60f2068dc); ?>
<?php endif; ?>

        <!-- Sidebar -->
        <?php if (isset($component)) { $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $attributes = $__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__attributesOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce)): ?>
<?php $component = $__componentOriginal329b1746a750ecc7ba22b48fb78d1fce; ?>
<?php unset($__componentOriginal329b1746a750ecc7ba22b48fb78d1fce); ?>
<?php endif; ?>

        <?php if (isset($component)) { $__componentOriginald3b387f4f5efe74d7afe13be62871c47 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald3b387f4f5efe74d7afe13be62871c47 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dashboard.header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e($title); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $attributes = $__attributesOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__attributesOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald3b387f4f5efe74d7afe13be62871c47)): ?>
<?php $component = $__componentOriginald3b387f4f5efe74d7afe13be62871c47; ?>
<?php unset($__componentOriginald3b387f4f5efe74d7afe13be62871c47); ?>
<?php endif; ?>

        <main class="p-4 md:ml-64 h-auto bg-gray-100">
            <?php echo e($slot); ?>

        </main>
    </div>
</body>

</html>
<?php /**PATH C:\laragon\www\alhakim\resources\views/components/dashboard/layout.blade.php ENDPATH**/ ?>