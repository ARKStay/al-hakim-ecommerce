<?php if (isset($component)) { $__componentOriginalf2b16bc3883246ba4659aff94e382522 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2b16bc3883246ba4659aff94e382522 = $attributes; } ?>
<?php $component = App\View\Components\Layouts\Layout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layouts\Layout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> Your Cart <?php $__env->endSlot(); ?>

    <?php if(session('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function () {
                Swal.fire({
                    icon: 'success',
                    title: 'Success!',
                    text: "<?php echo e(session('success')); ?>",
                    showConfirmButton: false,
                    timer: 3000,
                    toast: true,
                    position: 'bottom-end'
                });
            });
        </script>
    <?php endif; ?>

    <section class="py-12 bg-gray-50 dark:bg-gray-900">
        <div class="max-w-6xl mx-auto px-6">
            <h1 class="text-3xl font-bold mb-8 text-gray-800 dark:text-white">Shopping Cart</h1>

            <?php if($cartitems && $cartitems->count() > 0): ?>
                <div class="overflow-x-auto rounded-lg shadow">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-100 dark:bg-gray-800">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">No</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                                <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Qty</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Action</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200 dark:bg-gray-800 dark:divide-gray-700">
                            <?php $__currentLoopData = $cartitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $cartitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $variant = $cartitem->variant;
                                    $product = $variant?->product;
                                ?>

                                <tr>
                                    <td class="px-6 py-4"><?php echo e($index + 1); ?></td>

                                    <td class="px-6 py-4">
                                        <div class="flex items-start space-x-4">
                                            <img src="<?php echo e(asset('storage/' . ($product->image ?? 'no-image.jpg'))); ?>"
                                                alt="<?php echo e($product->name ?? 'Unknown Product'); ?>"
                                                class="w-16 h-16 object-cover border rounded shadow-sm">

                                            <img src="<?php echo e(asset('storage/' . ($variant->variant_image ?? 'no-image.jpg'))); ?>"
                                                alt="<?php echo e($variant->color ?? 'Variant'); ?>"
                                                class="w-16 h-16 object-cover border rounded shadow-sm">

                                            <div class="text-sm">
                                                <div class="font-bold text-gray-800 dark:text-white cursor-pointer"
                                                    title="<?php echo e($product->name); ?>">
                                                    <?php echo e(\Illuminate\Support\Str::limit($product->name, 25)); ?>

                                                </div>
                                                <div class="text-gray-600 dark:text-gray-400">
                                                    Warna: <?php echo e($variant->color); ?><br>
                                                    Ukuran: <?php echo e($variant->size); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <td class="px-6 py-4 text-gray-800 dark:text-white">
                                        Rp<?php echo e(number_format($cartitem->price, 0, ',', '.')); ?>

                                    </td>

                                    <td class="px-6 py-4 text-center text-gray-800 dark:text-white">
                                        <?php echo e($cartitem->quantity); ?>

                                    </td>

                                    <td class="px-6 py-4 font-semibold text-gray-900 dark:text-white">
                                        Rp<?php echo e(number_format($cartitem->price * $cartitem->quantity, 0, ',', '.')); ?>

                                    </td>

                                    <td class="px-6 py-4">
                                        <form action="<?php echo e(route('user.cart.delete', $cartitem->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="text-red-600 hover:text-red-800 transition">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                                                </svg>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <!-- Total & Checkout Section -->
                <div class="mt-8 p-6 rounded-lg bg-white dark:bg-gray-800 shadow flex flex-col md:flex-row justify-between items-center gap-6">
                    <div class="text-xl font-semibold text-gray-800 dark:text-white">
                        Total Price:
                        <span class="text-2xl font-bold text-blue-600 dark:text-blue-400 ml-2">
                            Rp<?php echo e(number_format($cart->total_price, 0, ',', '.')); ?>

                        </span>
                    </div>

                    <a href="<?php echo e(url('confirm_check_out')); ?>"
                        class="px-6 py-3 text-base font-semibold text-white bg-blue-600 rounded-md hover:bg-blue-700 shadow">
                        Proceed to Checkout
                    </a>
                </div>

                <!-- Tombol Kembali Belanja -->
                <div class="mt-6 flex justify-start">
                    <a href="/user/products"
                        class="inline-block px-6 py-3 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600">
                        ← Continue Shopping
                    </a>
                </div>
            <?php else: ?>
                <div class="flex flex-col items-center justify-center text-center mt-24 mb-24 space-y-4">
                    <p class="text-lg text-gray-600 dark:text-gray-400">Your cart is empty. Let's fill it up!</p>
                    <a href="/user/products"
                        class="mt-4 px-6 py-3 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 shadow">
                        Continue Shopping
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $attributes = $__attributesOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__attributesOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2b16bc3883246ba4659aff94e382522)): ?>
<?php $component = $__componentOriginalf2b16bc3883246ba4659aff94e382522; ?>
<?php unset($__componentOriginalf2b16bc3883246ba4659aff94e382522); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\alhakim\resources\views/user/cart/index.blade.php ENDPATH**/ ?>