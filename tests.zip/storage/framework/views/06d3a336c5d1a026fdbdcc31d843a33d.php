<header class="bg-white border-2">
    <div class="p-4 md:ml-64 h-auto pt-20">
        <h1 class="text-3xl font-bold tracking-tight text-gray-900"><?php echo e($slot); ?></h1>
    </div>
</header>
<?php /**PATH C:\laragon\www\alhakim\resources\views/components/dashboard/header.blade.php ENDPATH**/ ?>