<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Promotion;
use App\Mail\PromotionMail;
use Illuminate\Support\Facades\Mail;
use App\Models\User;

class DashboardCrmController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('dashboard.crm.index', [
            'title' => 'Promotion List',
            'promotions' => Promotion::all()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('dashboard.crm.create', ['title' => 'Add Promotion']);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'message' => 'required|string',
            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'product_link' => 'nullable|url',
        ]);

        // Simpan image kalau ada
        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('promotions', 'public');
        }

        $promotion = Promotion::create($validated);

        // 🔥 Kirim email ke semua user
        $users = User::all();
        foreach ($users as $user) {
            Mail::to($user->email)->send(new PromotionMail($promotion));
        }

        return redirect()->route('crm.index')->with('success', 'Promotion created & sent successfully!');
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Promotion $crm)
    {
        return view('dashboard.crm.edit', [
            'title' => 'Edit Promotion',
            'promotion' => $crm
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Promotion $crm)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'message' => 'required|string',
            'image' => 'nullable|image|mimes:jpg,jpeg,png|max:2048',
            'product_link' => 'nullable|url',
        ]);

        if ($request->hasFile('image')) {
            $validated['image'] = $request->file('image')->store('promotions', 'public');
        }

        $crm->update($validated);

        return redirect()->route('crm.index')->with('success', 'Promotion updated successfully!');
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Promotion $crm)
    {
        $crm->delete();

        return redirect()->route('crm.index')->with('success', 'Promotion deleted successfully!');
    }
}
