<x-mail::message>
    # {{ $title }}

    @if ($image)
        <p style="text-align:center; margin: 20px 0;">
            <img src="{{ url('promotions/' . $promotion->image) }}" alt="Promotion Image"
                style="max-width: 100%; height: auto; border-radius: 8px;">
        </p>
    @endif

    {{ $message }}

    @if ($product_link)
        <x-mail::button :url="$product_link">
            View Product
        </x-mail::button>
    @endif

    ---

    **Best regards,**
    {{ config('app.name') }}
</x-mail::message>
