<?php

return [
    'api_key' => env('RAJAONGKIR_API_KEY'),
];
